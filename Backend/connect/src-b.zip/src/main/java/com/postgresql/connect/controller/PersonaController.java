package com.postgresql.connect.controller;

import com.postgresql.connect.Specs.PersonaSpecs;
import com.postgresql.connect.model.Persona;
import com.postgresql.connect.repo.PersonaRepo;
import com.postgresql.connect.utils.PaginatedResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.ResponseEntity;


import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;

@RestController
public class PersonaController {

    @Autowired
    PersonaRepo personaRepo;


    @PostMapping("api/persona/create")
    public void addPersona(@RequestBody Persona persona) {
        personaRepo.save(persona);
    }


    @GetMapping("api/persona/list")
    public List<Persona> getAllPersonas() {
        return personaRepo.findAll();
    }

    @GetMapping("api/persona/listbyparams")
    public ResponseEntity<PaginatedResponse<Persona>> getAllPersonas2(
            @RequestParam("limite") int limite,
            @RequestParam("offset") int offset,
            @RequestParam(value = "busqueda", required = false) String busqueda
    ) {

        Pageable pageable = PageRequest.of(offset, limite);
        Page<Persona> page;

        Specification<Persona> specs = PersonaSpecs.searchByCriteria(busqueda); // Crear la especificación

        if (busqueda != null && !busqueda.isEmpty()) {
            page = personaRepo.findAll(specs, pageable); // Utilizar la especificación en la consulta
        } else {
            page = personaRepo.findAll(pageable);
        }

        List<Persona> personas = page.getContent();
        long totalRecords;

        if (busqueda != null && !busqueda.isEmpty()) {
            totalRecords = personaRepo.count(specs); // Contar utilizando la especificación
        } else {
            totalRecords = personaRepo.count();
        }

        PaginatedResponse<Persona> response = new PaginatedResponse<>(personas, totalRecords);
        System.out.println(response);
        // Devolver la respuesta con el código de estado 200 (OK)
        return ResponseEntity.ok(response);
    }


    @DeleteMapping("api/persona/delete/{id}")
    public void deleteById(@PathVariable Long id){
        personaRepo.deleteById(id);
    }

    @GetMapping("api/persona/{id}")
    public ResponseEntity<Persona> getPersonaById(@PathVariable Long id) {
        Optional<Persona> persona = personaRepo.findById(id);
        if (persona.isPresent()) {
            return ResponseEntity.ok(persona.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("api/persona/update/{id}")
    public Persona updatePersona(@PathVariable Long id, @RequestBody Persona persona) {
        Optional<Persona> personaExistenteOptional = personaRepo.findById(id);
        if (personaExistenteOptional.isPresent()) {
            Persona personaExistente = personaExistenteOptional.get();
            personaExistente.setNombre(persona.getNombre());
            personaExistente.setApellido(persona.getApellido());
            personaExistente.setGenero(persona.getGenero());
            personaExistente.setFechaNacimiento(persona.getFechaNacimiento());
            personaExistente.setEmail(persona.getEmail());
            personaExistente.setEstado(persona.getEstado());
            personaExistente.setIdentificacion(persona.getIdentificacion());
            personaExistente.setTipoIdentificacion(persona.getTipoIdentificacion());
            personaExistente.setDireccion(persona.getDireccion());
            personaExistente.setTelefono(persona.getTelefono());
            return personaRepo.save(personaExistente);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Persona no encontrada");
        }
    }



}
